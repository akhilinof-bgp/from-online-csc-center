# From Online CSC Center — Free Hosting Package

## Included
- Responsive CSC Center website
- Services, About, Contact sections
- Demo Admin Login and Dashboard
- No build tools required

## Demo Admin
Username: admin
Password: admin123

## Important
यह package demo/static admin panel है। Production में password को frontend HTML/JS में रखना सुरक्षित नहीं है। Real secure admin panel के लिए PHP + MySQL या Firebase backend जोड़ें.

## Free hosting
Static version GitHub Pages / Netlify / Cloudflare Pages पर चल सकता है। Admin demo भी static रूप में चलेगा, लेकिन data permanently save नहीं होगा.
